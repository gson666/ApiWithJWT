﻿using BackGammon_API.DTO;
using BackGammon_API.Helpers;
using BackGammon_API.Models;
using BackGammon_API.Service.Interfaces;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;

namespace BackGammon_API.Service
{
    public class UserService : IUser
    {
        private readonly UserManager<User> _userManager;
        private readonly JwtHandler _jwtHandler;
        public UserService(UserManager<User> userManager,JwtHandler jwtHandler)
        {
            _userManager = userManager;
            _jwtHandler = jwtHandler;
        }
        public async Task<string> Login(LoginDTO log)
        {
            var user = await _userManager.FindByNameAsync(log.UserName);
            if(user != null  && await _userManager.CheckPasswordAsync(user, log.Password))
            {
                var token = _jwtHandler.GenerateJwtToken(user);
                return token;
            }
            else
            {
                return "Invalid Login Action";
            }
        }

        public async Task<bool> Register(RegisterDTO reg)
        {
            var user = new User
            {
                FirstName = reg.FirstName,
                LastName = reg.LastName,
                UserName = reg.UserName,
                Email = reg.Email,
            };

            var result = await _userManager.CreateAsync(user,reg.Password);
            return result.Succeeded;
        }
    }
}
