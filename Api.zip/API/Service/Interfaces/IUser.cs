﻿using BackGammon_API.DTO;

namespace BackGammon_API.Service.Interfaces
{
    public interface IUser
    {
        Task<bool> Register(RegisterDTO reg);
        Task<string> Login(LoginDTO log);
    }
}
