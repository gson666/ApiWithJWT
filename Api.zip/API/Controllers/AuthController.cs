﻿using BackGammon_API.DTO;
using BackGammon_API.Helpers;
using BackGammon_API.Models;
using BackGammon_API.Service;
using BackGammon_API.Service.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlTypes;



namespace BackGammon_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUser _userService;
        public AuthController(IUser userService)
        {
            _userService = userService;
        }

        [HttpPost("register")]

        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDTO)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = await _userService.Register(registerDTO);

            if (result)
            {
                return Ok("Registeration Successfull");
            }
            else
            {
                return BadRequest("Registration Failed");
            }
        }

        [HttpPost("login")]

        public async Task<IActionResult> Login([FromBody] LoginDTO log)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var token = await _userService.Login(log);
            if (token != null && !token.Equals("Invalid Login Action"))
            {
                return Ok(new {token});
            }
            else
            {
                return BadRequest("Invalid Login Action");
            }
        }

    }
}
